
export default function Login() {
  return (
    <div className="flex items-center justify-center h-screen bg-gray-100">
      <div className="bg-white p-8 rounded shadow-md w-full max-w-md">
        <h2 className="text-2xl font-bold mb-6 text-center">Admin Girişi</h2>
        <input type="email" placeholder="E-posta" className="w-full mb-4 p-2 border rounded" />
        <input type="password" placeholder="Şifre" className="w-full mb-6 p-2 border rounded" />
        <button className="w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700">Giriş Yap</button>
      </div>
    </div>
  )
}
