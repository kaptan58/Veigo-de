
export default function Header() {
  return (
    <header className="bg-white p-4 shadow">
      <h1 className="text-2xl font-bold">Veigo Admin Panel</h1>
    </header>
  )
}
