
export default function Sidebar() {
  return (
    <aside className="w-64 bg-white shadow h-full p-4">
      <ul className="space-y-4">
        <li><a href="/" className="block text-blue-600 font-medium">Dashboard</a></li>
        <li><a href="/login" className="block text-gray-700">Çıkış</a></li>
      </ul>
    </aside>
  )
}
