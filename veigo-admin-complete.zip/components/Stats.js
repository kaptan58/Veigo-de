
export default function Stats() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div className="bg-white p-6 rounded shadow">
        <h3 className="text-lg font-semibold">Toplam Kazanç</h3>
        <p className="text-2xl mt-2">€12,450</p>
      </div>
      <div className="bg-white p-6 rounded shadow">
        <h3 className="text-lg font-semibold">Aktif Şoför</h3>
        <p className="text-2xl mt-2">32</p>
      </div>
      <div className="bg-white p-6 rounded shadow">
        <h3 className="text-lg font-semibold">Toplam Firma</h3>
        <p className="text-2xl mt-2">5</p>
      </div>
    </div>
  )
}
