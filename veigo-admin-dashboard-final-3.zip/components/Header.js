
export default function Header() {
  return (
    <header className="bg-white shadow p-4">
      <h1 className="text-xl font-bold">Veigo Yönetici Paneli</h1>
    </header>
  )
}
