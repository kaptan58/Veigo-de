// Main dashboard page
export default function Home() {
  return <div>Dashboard Ready</div>;
}