// Component example
export default function StatsCard() {
  return <div>Stats Card</div>;
}