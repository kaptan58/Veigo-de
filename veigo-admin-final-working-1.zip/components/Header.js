export default function Header() {
  return <header className="bg-white shadow p-4">Admin Panel Header</header>;
};